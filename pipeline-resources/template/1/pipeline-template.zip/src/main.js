import createApp from './create-app.js';

const { app } = createApp();

app.$mount('#app');
